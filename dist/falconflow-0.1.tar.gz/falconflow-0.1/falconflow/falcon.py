


class falcon:


    # constructor to initiate the parameters
    def __init__(self,struct = {}):

        self.struct = struct


    # constructor to represent the class data
    def __repr__(self):

        return self.struct
